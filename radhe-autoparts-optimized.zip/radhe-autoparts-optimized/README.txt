RADHE AUTO PARTS — OPTIMIZED STATIC WEBSITE

Contents
- index.html
- assets/ (optimized WebP images)
- favicon.svg

What was changed
- Extracted embedded JPEG images from the 3 MB HTML file into separate cacheable WebP files.
- Reduced the HTML file from about 2.99 MB to about 135 KB.
- Converted 36 unique image files to WebP (duplicate logo image is shared).
- Added intrinsic image dimensions and asynchronous decoding.
- Added lazy loading to non-critical images and high fetch priority to the main hero image.
- Kept existing page content, styles, scripts, links and interactive features otherwise intact.

Deploy
1. Extract this ZIP.
2. Upload the contents of the radhe-autoparts-optimized folder to your Vercel project root.
3. Ensure index.html is at the project root and the assets folder is alongside it.
4. Deploy, then test the deployed URL again with PageSpeed Insights on Mobile and Desktop.

Important
- This is a code-level optimization, not a verified Lighthouse retest. Scores can vary by device, network and test conditions.
- Test WhatsApp, phone, menu, gallery, product tabs, contact form and all sections after deployment.
- If your Vercel project already contains other files (for example, a serverless function or custom config), keep them; this ZIP is only the optimized static page and its assets.
